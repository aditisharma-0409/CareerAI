"""
Database Configuration
"""

HOST = "localhost"
PORT = 3306
USER = "root"
PASSWORD = "password"
DATABASE = "careerai_db"