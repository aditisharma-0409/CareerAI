
import os
import smtplib
import socket

from dotenv import load_dotenv
from email.message import EmailMessage

load_dotenv()


class IPv4SMTP_SSL(smtplib.SMTP_SSL):

    def _get_socket(self, host, port, timeout):
        ipv4_address = socket.gethostbyname(host)

        sock = socket.create_connection(
            (ipv4_address, port),
            timeout,
            self.source_address
        )

        return self.context.wrap_socket(
            sock,
            server_hostname=host
        )


def send_resumes_to_company(hr_email, resume_files):

    sender_email = os.getenv("CAREERAI_EMAIL", "").strip()
    sender_password = (
        os.getenv("CAREERAI_EMAIL_PASSWORD", "")
        .replace(" ", "")
        .strip()
    )

    if not sender_email or not sender_password:
        return False, "Email credentials are not configured."

    if not resume_files:
        return False, "No resumes were selected."

    message = EmailMessage()
    message["Subject"] = "Student Resumes - Placement Drive"
    message["From"] = sender_email
    message["To"] = hr_email

    message.set_content(
        "Dear HR Team,\n\n"
        "Please find attached the selected student resumes "
        "for your placement drive.\n\n"
        "Regards,\nCareerAI Placement Team"
    )

    for resume in resume_files:

        file_path = resume["file_path"]

        if not os.path.isfile(file_path):
            return False, f"Resume file not found: {resume['file_name']}"

        with open(file_path, "rb") as file:
            message.add_attachment(
                file.read(),
                maintype="application",
                subtype="pdf",
                filename=resume["file_name"]
            )

    try:
        with IPv4SMTP_SSL(
            "smtp.gmail.com",
            465,
            timeout=30
        ) as smtp:

            smtp.login(sender_email, sender_password)
            smtp.send_message(message)

        return True, "Resumes sent successfully."

    except Exception as error:
        return False, f"Email sending failed: {error}"
